
using InventoryProject.IRepositories;
using InventoryProject.Repositories;
//using InventoryProject.Repositories;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<DbHelper>();
builder.Services.AddScoped<IUserTransactionRepository, UserTransactionRepository>();
builder.Services.AddScoped<IRoleRepository, RoleRepository>();
builder.Services.AddScoped<IUserLevelTransactionRepository, UserLevelTransactionRepository>();
builder.Services.AddScoped<IRoleAccessRepository, RoleAccessRepository>();
builder.Services.AddScoped<IUserLoginRepository, UserLoginRepository>();
builder.Services.AddScoped<ISystemInformationRepository, SystemInformationRepository>();



// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();