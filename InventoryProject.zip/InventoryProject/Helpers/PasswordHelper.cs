﻿using System.Security.Cryptography;
using System.Text;

public static class PasswordHelper
{
    public static string Hash(string password)
    {
        using var sha = SHA256.Create();
        byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
        return Convert.ToBase64String(bytes);
    }

    public static bool Verify(string inputPassword, string dbPassword)
    {
        string inputHash = Hash(inputPassword);
        return inputHash == dbPassword;
    }
}
