﻿namespace InventoryProject.Models
{
    public class UserLoginDashboardDbDto
    {
        public int UserId { get; set; }
        public string UserName { get; set; }

        public DateTime? TodayLoginDateTime { get; set; }
        public DateTime? LastLoginDateTime { get; set; }
    }

}
