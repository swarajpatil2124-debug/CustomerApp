﻿namespace InventoryProject.Models
{
    public class DashboardLoginInfoDto
    {
        public string UserName { get; set; }
        public DateTime? TodayLoginDate { get; set; }
        public string TodayLoginTime { get; set; }
        public DateTime? LastLoginDate { get; set; }
        public string LastLoginTime { get; set; }
    }
}

