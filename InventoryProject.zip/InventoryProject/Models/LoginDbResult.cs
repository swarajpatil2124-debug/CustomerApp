﻿namespace InventoryProject.Models
{
    public class LoginDbResult
    {
        public string Status { get; set; }
        public int UserId { get; set; }
        public string LoginId { get; set; }
        public string UserName { get; set; }
        public string Name { get; set; }
        public int RoleId { get; set; }
        public int UserLevelId { get; set; }
        public bool IsUserActive { get; set; }
        public bool IsLocked { get; set; }
        public string PasswordHash { get; set; }
    }

}
