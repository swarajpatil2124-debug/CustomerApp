﻿namespace InventoryProject.Models
{
    public class UserLevelTransactionDto
    {
        public int Id { get; set; }
        public int UserLevelId { get; set; }
        public string LevelName { get; set; }

        public DateTime? CreatedDate { get; set; }
        public int Creator { get; set; }

        public string Approver { get; set; }
        public DateTime? ApprovalDate { get; set; }

        public string ApprovalStatus { get; set; }
        public string ReasonForDisapproval { get; set; }
    }

}
