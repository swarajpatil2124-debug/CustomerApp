﻿namespace InventoryProject.Models
{
    public class ApplicationObjectDto
    {
        public int Id { get; set; }

       
        public string ObjectName { get; set; }

       
        public string DisplayName { get; set; }

        public bool IsActive { get; set; }
    }
}
