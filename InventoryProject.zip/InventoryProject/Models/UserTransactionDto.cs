﻿namespace InventoryProject.Models
{
    public class UserTransactionDto
    {
        public int Id { get; set; }

        public int CompanyId { get; set; }
        public int BranchId { get; set; }

        public string UserName { get; set; }
        public string Name { get; set; }

        public string LoginId { get; set; }
        public string Password { get; set; }   

        public string Email { get; set; }
        public string MobileNo { get; set; }

        public int UserLevelId { get; set; }
        public int RoleId { get; set; }
        public int JobDescriptionId { get; set; }

        public bool IsUserActive { get; set; }
        public bool IsExternalUser { get; set; }

        public string Creator { get; set; }
    }

}
