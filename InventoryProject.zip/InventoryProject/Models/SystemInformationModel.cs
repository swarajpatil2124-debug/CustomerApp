﻿namespace InventoryProject.Models
{
    public class SystemInformationModel
    {
        public int CompanyId { get; set; }

        public string? CompanyCode { get; set; }
        public string? CompanyName { get; set; }
        public string? CompanyShortName { get; set; }
        public string? CompanyCategory { get; set; }
        public string? CompanyType { get; set; }

        public int? FinancialYearFrom { get; set; }
        public int? FinancialYearTo { get; set; }
        public DateTime? FinancialStartDate { get; set; }
        public DateTime? FinancialEndDate { get; set; }

        public string? Address { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? Pincode { get; set; }

        public string? Phone { get; set; }
        public string? MobileNumber { get; set; }
        public string? LandlineNumber { get; set; }
        public string? FaxNumber { get; set; }
        public string? EmailId { get; set; }
        public string? Website { get; set; }
        public string? ContactPersonName { get; set; }

        public string? GSTNumber { get; set; }
        public string? PANNumber { get; set; }

        public decimal? OpeningBalance { get; set; }
        public string? OpeningBalanceType { get; set; }

        public int? CoYearFrom { get; set; }
        public int? CoYearTo { get; set; }
        public DateTime? CoStartDate { get; set; }
        public DateTime? CoEndDate { get; set; }

        public int? BranchId { get; set; }
        public string? WeeklyHoliday { get; set; }

        public bool? IsActive { get; set; }
    }
}
