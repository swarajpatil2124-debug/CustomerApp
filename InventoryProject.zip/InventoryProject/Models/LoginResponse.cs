﻿namespace InventoryProject.Models
{
    public class LoginResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }

        public int UserId { get; set; }
        public string LoginId { get; set; }
        public string UserName { get; set; }
        public string Name { get; set; }

        public int RoleId { get; set; }
        public int UserLevelId { get; set; }
       
        public DateTime LoginTime { get; set; }
    }


}