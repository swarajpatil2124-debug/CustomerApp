﻿namespace InventoryProject.Models
{
    public class DashboardMenuModel
    {
        public int ObjectId { get; set; }
        public string ObjectName { get; set; }
        public string DisplayName { get; set; }

        public bool CanView { get; set; }
        public bool CanAdd { get; set; }
        public bool CanEdit { get; set; }
        public bool CanDelete { get; set; }
        public bool CanPrint { get; set; }
        public bool CanApprove { get; set; }
    }
}
