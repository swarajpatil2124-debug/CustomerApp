﻿public class CompanySelectModel
{
    public int CompanyId { get; set; }
    public string CompanyName { get; set; }
    public string? CompanyShortName { get; set; }

    public int CoYearFrom { get; set; }
    public int CoYearTo { get; set; }

    public DateTime CoStartDate { get; set; }
    public DateTime? CoEndDate { get; set; }
}
