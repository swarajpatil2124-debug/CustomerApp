﻿namespace InventoryProject.Models
{
    public class LoginRequest
    {
        public string LoginId { get; set; }
        public string Password { get; set; }
    }
}
