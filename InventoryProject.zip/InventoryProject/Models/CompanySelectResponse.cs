﻿namespace InventoryProject.Models
{
    public class CompanySelectResponse
    {
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string UserName { get; set; }
        public DateTime LoginTime { get; set; }
    }
}