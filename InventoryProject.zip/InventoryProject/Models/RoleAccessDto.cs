﻿namespace InventoryProject.Models
{
    public class RoleAccessDto
    {
        public int Id { get; set; }
        public int RoleId { get; set; }
        public int ObjectId { get; set; }
        public string Access { get; set; }

        public bool CanView { get; set; }
        public bool CanAdd { get; set; }
        public bool CanEdit { get; set; }
        public bool CanDelete { get; set; }
        public bool CanPrint { get; set; }
        public bool CanApprove { get; set; }

        public bool IsActive { get; set; }
    }

}
