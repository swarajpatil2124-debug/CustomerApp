﻿namespace InventoryProject.Models
{
    public class RoleAccessListDto
    {
        public int Id { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; }

        public int ObjectId { get; set; }
        public string ObjectName { get; set; }

        public bool CanView { get; set; }
        public bool CanAdd { get; set; }
        public bool CanEdit { get; set; }
        public bool CanDelete { get; set; }
        public bool CanPrint { get; set; }
        public bool CanApprove { get; set; }

        public bool IsActive { get; set; }
    }
}
