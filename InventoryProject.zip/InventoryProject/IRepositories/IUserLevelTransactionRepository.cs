﻿using InventoryProject.Models;

namespace InventoryProject.IRepositories
{
    public interface IUserLevelTransactionRepository
    {
        Task<string> Insert(UserLevelTransactionDto dto);
        Task<string> Update(UserLevelTransactionDto dto);
        Task<string> Approve(UserLevelTransactionDto dto);
        Task<string> Delete(int id);
        Task<IEnumerable<UserLevelTransactionDto>> List();
    }

}
