﻿using InventoryProject.Models;

namespace InventoryProject.IRepositories
{
    public interface IUserTransactionRepository
    {
        Task<string> InsertUser(UserTransactionDto model);
        Task<string> UpdateUser(UserTransactionDto model);
        Task<string> DeleteUser(int id);
        Task<IEnumerable<UserTransactionDto>> GetUserList();

    }
}
    