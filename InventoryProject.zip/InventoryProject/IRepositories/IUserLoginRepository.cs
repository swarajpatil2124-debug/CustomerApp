﻿using InventoryProject.Models;

namespace InventoryProject.IRepositories
{
        public interface IUserLoginRepository
        {
            Task<int> LogUserLogin(int userId, string computerName);
            Task LogoutUser(int userId);
             Task<UserLoginDashboardDbDto> GetDashboardLoginInfo(int userId);

    }

}
