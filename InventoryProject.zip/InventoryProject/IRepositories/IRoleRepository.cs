﻿using InventoryProject.Models;


namespace InventoryProject.IRepositories
{
public interface IRoleRepository
{
    Task<string> Insert(RoleDto role);
    Task<string> Update(RoleDto role);
    Task<string> Delete(int id);
    Task<IEnumerable<RoleDto>> List(int? companyId);
}
}