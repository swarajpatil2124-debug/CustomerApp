﻿using InventoryProject.Models;

namespace InventoryProject.IRepositories
{
    public interface IRoleAccessRepository
    {
        Task<string> Save(RoleAccessDto model);
        Task<string> Delete(int id);
        Task<IEnumerable<RoleAccessListDto>> GetRoleAccessListByRole(int roleId);
        Task<IEnumerable<DashboardMenuModel>> GetDashboard(int roleId);

        // All objects list (optional use)
       // Task<IEnumerable<RoleAccessListDto>> GetRoleAccessList();

    
    }
}
