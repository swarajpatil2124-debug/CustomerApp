﻿using InventoryProject.Models;

using InventoryProject.Models;

namespace InventoryProject.IRepositories
{
    public interface ISystemInformationRepository
    {
        Task<int> InsertAsync(SystemInformationModel model);
        Task<int> UpdateAsync(SystemInformationModel model);
        Task<bool> DeleteAsync(int companyId);
        Task<List<SystemInformationModel>> GetListAsync();
        Task<SystemInformationModel?> GetByIdAsync(int companyId);
    }
}

