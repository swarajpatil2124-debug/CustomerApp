﻿using InventoryProject.IRepositories;
using InventoryProject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace InventoryProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserLevelTransactionController : ControllerBase
    {
        private readonly IUserLevelTransactionRepository _repo;

        public UserLevelTransactionController(IUserLevelTransactionRepository repo)
        {
            _repo = repo;
        }

        [HttpPost("create")]
        public async Task<IActionResult> Create(UserLevelTransactionDto dto)
        {
            var result = await _repo.Insert(dto);
            return Ok(result);
        }

        [HttpPut("update")]
        public async Task<IActionResult> Update(UserLevelTransactionDto dto)
        {
            var result = await _repo.Update(dto);
            return Ok(result);
        }

        [HttpPost("approve")]
        public async Task<IActionResult> Approve(UserLevelTransactionDto dto)
        {
            var result = await _repo.Approve(dto);
            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var result = await _repo.Delete(id);
            return Ok(result);
        }

        [HttpGet("list")]
        public async Task<IActionResult> List()
        {
            var data = await _repo.List();
            return Ok(data);
        }
    }
}