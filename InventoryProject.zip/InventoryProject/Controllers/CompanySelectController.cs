﻿using Dapper;
using InventoryProject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data;

namespace InventoryProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanySelectController : ControllerBase
    {
        private readonly DbHelper _db;

        public CompanySelectController(DbHelper db)
        {
            _db = db;
        }

        // 🔹 Login ke baad Company Selection list
        [HttpGet("list")]
        public async Task<IActionResult> GetCompanyList()
        {
            using var connection = _db.GetConnection();

            var companies = await connection.QueryAsync<CompanySelectModel>(
                "Get_Company_List",
                commandType: CommandType.StoredProcedure
            );

            return Ok(companies);
        }

        // 🔹 Company select karne ke baad
        [HttpPost("select")]
        public async Task<IActionResult> SelectCompany([FromBody] CompanySelectModel request)
        {
            using var connection = _db.GetConnection();

            var company = await connection.QueryFirstOrDefaultAsync<CompanySelectModel>(
                "sp_Company_Select",
                new { CompanyId = request.CompanyId },
                commandType: CommandType.StoredProcedure
            );

            if (company == null)
                return NotFound("Company not found");

            

            return Ok(new CompanySelectModel
            {
                CompanyId = company.CompanyId,
                CompanyName = company.CompanyName,
                CoYearFrom = company.CoYearFrom,
                CoYearTo = company.CoYearTo
            });
        }
    }
}