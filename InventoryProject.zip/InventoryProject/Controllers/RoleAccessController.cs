﻿using InventoryProject.IRepositories;
using InventoryProject.Models;
using Microsoft.AspNetCore.Mvc;

namespace InventoryProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleAccessController : ControllerBase
    {
        private readonly IRoleAccessRepository _repo;

        public RoleAccessController(IRoleAccessRepository repo)
        {
            _repo = repo;
        }

        /* ================= SAVE (UPSERT) ================= */
        [HttpPost("save")]
        public async Task<IActionResult> Save([FromBody] RoleAccessDto model)
        {
            var result = await _repo.Save(model);
            return Ok(result);
        }

        /* ================= DELETE ================= */
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var result = await _repo.Delete(id);
            return Ok(result);
        }

        /* ================= LIST (ROLE ACCESS PAGE) ================= */
        [HttpGet("list/{roleId}")]
        public async Task<IActionResult> ListByRole(int roleId)
        {
            var data = await _repo.GetRoleAccessListByRole(roleId);
            return Ok(data);
        }

        /* ================= DASHBOARD MENU ================= */
        [HttpGet("dashboard/{roleId}")]
        public async Task<IActionResult> Dashboard(int roleId)
        {
            var data = await _repo.GetDashboard(roleId);
            return Ok(data);
        }
    }
}
