﻿using InventoryProject.IRepositories;
using InventoryProject.Models;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class UserTransactionController : ControllerBase
{
    private readonly IUserTransactionRepository _repo;

    public UserTransactionController(IUserTransactionRepository repo)
    {
        _repo = repo;
    }

    [HttpPost("insert")]
    public async Task<IActionResult> Insert(UserTransactionDto model)
    {
        var result = await _repo.InsertUser(model);

        if (result == "LOGINID_ALREADY_EXISTS")
            return BadRequest("LoginId already exists");

        return Ok(result);
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update(UserTransactionDto model)
    {
        var result = await _repo.UpdateUser(model);
        return Ok(result);
    }

    [HttpDelete("delete/{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _repo.DeleteUser(id);
        return Ok(result);
    }

    [HttpGet("list")]
    public async Task<IActionResult> List()
    {
        var users = await _repo.GetUserList();
        return Ok(users);
    }
}
