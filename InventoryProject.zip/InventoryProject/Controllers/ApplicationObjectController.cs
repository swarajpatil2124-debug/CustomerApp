﻿using Dapper;
using InventoryProject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace InventoryProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicationObjectController : ControllerBase
    {
        private readonly IDbConnection _db;

        public ApplicationObjectController(IConfiguration config)
        {
            _db = new SqlConnection(config.GetConnectionString("DefaultConnection"));
        }

        // GET api/applicationobject/list
        [HttpGet("list")]
        public async Task<IActionResult> GetList()
        {
            var data = await _db.QueryAsync<ApplicationObjectDto>(
                @"SELECT Id, ObjectName, DisplayName
              FROM ApplicationObject
              WHERE IsActive = 1
              ORDER BY DisplayName"
            );

            return Ok(data);
        }
    }
}