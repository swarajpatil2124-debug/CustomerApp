﻿using InventoryProject.IRepositories;
using InventoryProject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace InventoryProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly IRoleRepository _repo;

        public RoleController(IRoleRepository repo)
        {
            _repo = repo;
        }

        
        [HttpPost("insert")]
        public async Task<IActionResult> Insert(RoleDto role)
        {
            var result = await _repo.Insert(role);
            return Ok(new { Message = result });
        }

        
        [HttpPut("update")]
        public async Task<IActionResult> Update(RoleDto role)
        {
            var result = await _repo.Update(role);
            return Ok(new { Message = result });
        }

       
        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var result = await _repo.Delete(id);
            return Ok(new { Message = result });
        }

      
        [HttpGet("list")]
        public async Task<IActionResult> List([FromQuery] int? companyId)
        {
            var roles = await _repo.List(companyId);
            return Ok(roles);
        }
    }
}