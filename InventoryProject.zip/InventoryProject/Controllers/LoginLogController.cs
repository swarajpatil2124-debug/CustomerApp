﻿using InventoryProject.IRepositories;
using InventoryProject.Models;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class LoginLogController : ControllerBase
{
    private readonly IUserLoginRepository _repo;

    public LoginLogController(IUserLoginRepository repo)
    {
        _repo = repo;
    }

    // ================= LOGIN =================
    [HttpPost("login/{userId}")]
    public async Task<IActionResult> Login(int userId)
    {
        string computerName = Environment.MachineName;

        await _repo.LogUserLogin(userId, computerName);

        return Ok("LOGIN_LOGGED");
    }

    // ================= LOGOUT =================
    [HttpPost("logout/{userId}")]
    public async Task<IActionResult> Logout(int userId)
    {
        await _repo.LogoutUser(userId);
        return Ok("LOGOUT_LOGGED");
    }

    //// ================= DASHBOARD TOP BAR =================
    //[HttpGet("dashboard/{userId}")]
    //public async Task<IActionResult> GetDashboardInfo(int userId)
    //{
    //    var data = await _repo.GetDashboardLoginInfo(userId);
    //    return Ok(data);
    //}
    [HttpGet("dashboard/{userId}")]
    public async Task<IActionResult> Dashboard(int userId)
    {
        var data = await _repo.GetDashboardLoginInfo(userId);

        if (data == null)
            return Ok(null);

        var response = new DashboardLoginInfoDto
        {
            UserName = data.UserName,

            TodayLoginDate = data.TodayLoginDateTime?.Date,
            TodayLoginTime = data.TodayLoginDateTime?.ToString("hh:mm tt"),

            LastLoginDate = data.LastLoginDateTime?.Date,
            LastLoginTime = data.LastLoginDateTime?.ToString("hh:mm tt")
        };

        return Ok(response);
    }
}

