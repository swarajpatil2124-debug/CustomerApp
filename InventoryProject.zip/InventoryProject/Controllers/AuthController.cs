﻿using Dapper;
using InventoryProject.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly DbHelper _db;

    public AuthController(DbHelper db)
    {
        _db = db;
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        using var con = _db.GetConnection();

        var result = await con.QueryFirstOrDefaultAsync<LoginDbResult>(
            "sp_Login",
            new { LoginId = request.LoginId },
            commandType: CommandType.StoredProcedure
        );

        if (result == null)
            return Unauthorized(new { success = false, message = "Invalid login" });

        if (!PasswordHelper.Verify(request.Password, result.PasswordHash))
            return Unauthorized(new { success = false, message = "Invalid password" });

        if (!result.IsUserActive)
            return Unauthorized(new { success = false, message = "User inactive" });

        if (result.IsLocked)
            return Unauthorized(new { success = false, message = "User locked" });

        return Ok(new LoginResponse
        {
            Success = true,
            Message = "Login Successful",

            UserId = result.UserId,
            LoginId = result.LoginId,
            UserName = result.UserName,
            Name = result.Name,

            RoleId = result.RoleId,          
            UserLevelId = result.UserLevelId,
            LoginTime = DateTime.Now
        });
    }

}

