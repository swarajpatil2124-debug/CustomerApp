﻿using InventoryProject.IRepositories;
using InventoryProject.Models;
using Microsoft.AspNetCore.Mvc;

namespace InventoryProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")] 
    public class SystemInformationController : ControllerBase
    {
        private readonly ISystemInformationRepository _repo;

        public SystemInformationController(ISystemInformationRepository repo)
        {
            _repo = repo;
        }


        [HttpPost("insert")]
        public async Task<IActionResult> Insert([FromBody] SystemInformationModel model)
            => Ok(await _repo.InsertAsync(model));

        [HttpPut("update")]
        public async Task<IActionResult> Update([FromBody] SystemInformationModel model)
            => Ok(await _repo.UpdateAsync(model));

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _repo.DeleteAsync(id);
            return Ok(new { Success = true });
        }

        [HttpGet("list")]
        public async Task<IActionResult> List()
        {
            return Ok(await _repo.GetListAsync());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var data = await _repo.GetByIdAsync(id);
            if (data == null) return NotFound();
            return Ok(data);
        }
    }
}
