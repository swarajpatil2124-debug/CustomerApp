﻿using Dapper;
using InventoryProject.IRepositories;
using InventoryProject.Models;
using Microsoft.Data.SqlClient;
using System.Data;

namespace InventoryProject.Repositories
{
    public class RoleAccessRepository : IRoleAccessRepository
    {
        private readonly IConfiguration _config;

        public RoleAccessRepository(IConfiguration config)
        {
            _config = config;
        }

        private IDbConnection Connection =>
            new SqlConnection(_config.GetConnectionString("DefaultConnection"));

        /* ================= SAVE (UPSERT) ================= */
        public async Task<string> Save(RoleAccessDto model)
        {
            using var db = Connection;

            return await db.QuerySingleAsync<string>(
                "IUD_RoleAccess",
                new
                {
                    Action = "SAVE",   
                    model.Id,
                    model.RoleId,
                    model.ObjectId,
                    model.Access,
                    model.CanView,
                    model.CanAdd,
                    model.CanEdit,
                    model.CanDelete,
                    model.CanPrint,
                    model.CanApprove
                },
                commandType: CommandType.StoredProcedure
            );
        }


        /* ================= DELETE (SOFT) ================= */
        public async Task<string> Delete(int id)
        {
            using var db = Connection;

            return await db.QuerySingleAsync<string>(
                "IUD_RoleAccess",
                new
                {
                    Action = "DELETE",
                    Id = id
                },
                commandType: CommandType.StoredProcedure
            );
        }

        /* ================= ROLE ACCESS LIST (ROLE WISE) ================= */
        public async Task<IEnumerable<RoleAccessListDto>> GetRoleAccessListByRole(int roleId)
        {
            using var db = Connection;

            return await db.QueryAsync<RoleAccessListDto>(
                "IUD_RoleAccess",
                new
                {
                    Action = "LIST",
                    RoleId = roleId
                },
                commandType: CommandType.StoredProcedure
            );
        }

        /* ================= DASHBOARD MENU ================= */
        public async Task<IEnumerable<DashboardMenuModel>> GetDashboard(int roleId)
        {
            using var db = Connection;

            return await db.QueryAsync<DashboardMenuModel>(
                "IUD_RoleAccess",
                new
                {
                    Action = "DASHBOARD",
                    RoleId = roleId
                },
                commandType: CommandType.StoredProcedure
            );
        }
    }
}
