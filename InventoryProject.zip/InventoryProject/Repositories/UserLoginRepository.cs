﻿using Dapper;
using InventoryProject.IRepositories;
using InventoryProject.Models;
using Microsoft.Data.SqlClient;
using System.Data;

public class UserLoginRepository : IUserLoginRepository
{
    private readonly IConfiguration _config;

    public UserLoginRepository(IConfiguration config)
    {
        _config = config;
    }

    private IDbConnection Connection =>
    new SqlConnection(_config.GetConnectionString("DefaultConnection"));

    // ================= LOGIN =================
    public async Task<int> LogUserLogin(int userId, string computerName)
    {
        using var db = Connection;

        return await db.ExecuteAsync(
            "USP_UserLogin_Insert",
            new
            {
                UserId = userId,
                 ComputerName = computerName
            },
            commandType: CommandType.StoredProcedure
        );
    }

    // ================= LOGOUT =================
    public async Task LogoutUser(int userId)
    {
        using var db = Connection;

        await db.ExecuteAsync(
            "USP_UserLogout_Update",
            new
            {
                UserId = userId
            },
            commandType: CommandType.StoredProcedure
        );
    }

    // ================= DASHBOARD INFO =================
    public async Task<UserLoginDashboardDbDto> GetDashboardLoginInfo(int userId)
    {
        using var db = Connection;

        return await db.QueryFirstOrDefaultAsync<UserLoginDashboardDbDto>(
            "USP_UserLogin_Dashboard",
            new { UserId = userId },
            commandType: CommandType.StoredProcedure
        );
    }

}
