﻿using Dapper;
using InventoryProject.IRepositories;
using InventoryProject.Models;
using Microsoft.Data.SqlClient;
using System.Data;

public class UserLevelTransactionRepository : IUserLevelTransactionRepository
{
    private readonly IConfiguration _config;

    public UserLevelTransactionRepository(IConfiguration config)
    {
        _config = config;
    }

    private IDbConnection Connection =>
        new SqlConnection(_config.GetConnectionString("DefaultConnection"));

    public async Task<string> Insert(UserLevelTransactionDto dto)
    {
        using var db = Connection;

        return await db.QueryFirstAsync<string>(
            "IUD_UserLevelTransaction",
            new
            {
                Action = "INSERT",
                dto.UserLevelId,
                dto.LevelName,
                dto.CreatedDate,
                dto.Creator,
                dto.Approver,
                dto.ApprovalDate,
                dto.ApprovalStatus,
                dto.ReasonForDisapproval
            },
            commandType: CommandType.StoredProcedure
        );
    }

    public async Task<string> Update(UserLevelTransactionDto dto)
    {
        using var db = Connection;

        return await db.QueryFirstAsync<string>(
            "IUD_UserLevelTransaction",
            new
            {
                Action = "UPDATE",
                dto.Id,
                dto.LevelName
            },
            commandType: CommandType.StoredProcedure
        );
    }

    public async Task<string> Approve(UserLevelTransactionDto dto)
    {
        using var db = Connection;

        return await db.QueryFirstAsync<string>(
            "IUD_UserLevelTransaction",
            new
            {
                Action = "APPROVE",
                dto.Id,
                dto.UserLevelId,
                dto.LevelName,
                dto.Approver
            },
            commandType: CommandType.StoredProcedure
        );
    }

    public async Task<string> Delete(int id)
    {
        using var db = Connection;

        return await db.QueryFirstAsync<string>(
            "IUD_UserLevelTransaction",
            new
            {
                Action = "DELETE",
                Id = id
            },
            commandType: CommandType.StoredProcedure
        );
    }

    public async Task<IEnumerable<UserLevelTransactionDto>> List()
    {
        using var db = Connection;

        return await db.QueryAsync<UserLevelTransactionDto>(
            "IUD_UserLevelTransaction",
            new { Action = "LIST" },
            commandType: CommandType.StoredProcedure
        );
    }
}
