﻿using Dapper;
using InventoryProject.IRepositories;
using InventoryProject.Models;
using Microsoft.Data.SqlClient;
using System.Data;

public class UserTransactionRepository : IUserTransactionRepository
{
    private readonly IConfiguration _config;

    public UserTransactionRepository(IConfiguration config)
    {
        _config = config;
    }

    private IDbConnection Connection =>
        new SqlConnection(_config.GetConnectionString("DefaultConnection"));

    public async Task<string> InsertUser(UserTransactionDto model)
    {
        using var db = Connection;

        string hashedPassword = PasswordHelper.Hash(model.Password); 

        var result = await db.QueryFirstAsync<string>(
            "IUD_UserTransaction",
            new
            {
                Action = "INSERT",
                model.CompanyId,
                model.BranchId,
                model.UserName,
                model.Name,
                model.LoginId,
                Password = hashedPassword, 
                model.Email,
                model.MobileNo,
                model.UserLevelId,
                model.RoleId,
                model.JobDescriptionId,
                model.IsExternalUser,
                model.Creator
            },
            commandType: CommandType.StoredProcedure
        );

        return result;
    }


    public async Task<string> UpdateUser(UserTransactionDto model)
    {
        using var db = Connection;

        string hashedPassword = null;

       
        if (!string.IsNullOrEmpty(model.Password))
        {
            hashedPassword = PasswordHelper.Hash(model.Password);
        }

        var result = await db.QueryFirstAsync<string>(
            "IUD_UserTransaction",
            new
            {
                Action = "UPDATE",
                model.Id,
                model.CompanyId,
                model.BranchId,
                model.UserName,
                model.Name,
                model.LoginId,
                model.Email,
                model.MobileNo,
                model.UserLevelId,
                model.RoleId,
                model.JobDescriptionId,
                model.IsUserActive,
                model.IsExternalUser,
                Password = hashedPassword,   
                ExpireDays = 90              
            },
            commandType: CommandType.StoredProcedure
        );

        return result;
    }


    public async Task<string> DeleteUser(int id)
    {
        using var db = Connection;

        var result = await db.QueryFirstAsync<string>(
            "IUD_UserTransaction",
            new
            {
                Action = "DELETE",
                Id = id
            },
            commandType: CommandType.StoredProcedure
        );

        return result;
    }

    public async Task<IEnumerable<UserTransactionDto>> GetUserList()
    {
        using var db = Connection;

        return await db.QueryAsync<UserTransactionDto>(
            "IUD_UserTransaction",
            new { Action = "LIST" },
            commandType: CommandType.StoredProcedure
        );
    }

}
