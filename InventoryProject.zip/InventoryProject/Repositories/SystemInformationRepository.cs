﻿using Dapper;
using InventoryProject.IRepositories;
using InventoryProject.Models;
using System.Data;

namespace InventoryProject.Repositories
{
    public class SystemInformationRepository : ISystemInformationRepository
    {
        private readonly DbHelper _db;

        public SystemInformationRepository(DbHelper db)
        {
            _db = db;
        }

        public Task<int> InsertAsync(SystemInformationModel model)
            => ExecuteAsync(model, "INSERT");

        public Task<int> UpdateAsync(SystemInformationModel model)
            => ExecuteAsync(model, "UPDATE");

        public async Task<bool> DeleteAsync(int companyId)
        {
            using var con = _db.GetConnection();
            await con.ExecuteAsync(
                "IUD_SystemInformation",
                new { Action = "DELETE", CompanyId = companyId },
                commandType: CommandType.StoredProcedure
            );
            return true;
        }

        public async Task<List<SystemInformationModel>> GetListAsync()
        {
            using var con = _db.GetConnection();
            var data = await con.QueryAsync<SystemInformationModel>(
                "IUD_SystemInformation",
                new { Action = "LIST" },
                commandType: CommandType.StoredProcedure
            );
            return data.ToList();
        }

        public async Task<SystemInformationModel?> GetByIdAsync(int companyId)
        {
            using var con = _db.GetConnection();
            return await con.QueryFirstOrDefaultAsync<SystemInformationModel>(
                "IUD_SystemInformation",
                new { Action = "LIST", CompanyId = companyId },
                commandType: CommandType.StoredProcedure
            );
        }

        private async Task<int> ExecuteAsync(SystemInformationModel m, string action)
        {
            using var con = _db.GetConnection();
            var p = new DynamicParameters();
            p.Add("@Action", action);

            if (action == "UPDATE" || action == "DELETE")
                p.Add("@CompanyId", m.CompanyId);

            // ✅ Only parameters that exist in SP
            var spParams = new[]
            {
                "CompanyCode","CompanyName","CompanyShortName","CompanyCategory","CompanyType",
                "FinancialYearFrom","FinancialYearTo","FinancialStartDate","FinancialEndDate",
                "Address","City","State","Pincode",
                "Phone","MobileNumber","LandlineNumber","FaxNumber","EmailId","Website","ContactPersonName",
                "GSTNumber","PANNumber","OpeningBalance","OpeningBalanceType",
                "CoYearFrom","CoYearTo","CoStartDate","CoEndDate",
                "BranchId","WeeklyHoliday","IsActive"
            };

            foreach (var prop in typeof(SystemInformationModel).GetProperties())
            {
                if (spParams.Contains(prop.Name))
                {
                    var value = prop.GetValue(m);
                    p.Add("@" + prop.Name, value);
                }
            }

            return await con.ExecuteScalarAsync<int>(
                "IUD_SystemInformation",
                p,
                commandType: CommandType.StoredProcedure
            );
        }
    }
}
