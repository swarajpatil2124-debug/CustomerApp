﻿using Dapper;
using InventoryProject.IRepositories;
using InventoryProject.Models;
using Microsoft.Data.SqlClient;
using System.Data;

public class RoleRepository : IRoleRepository
{
    private readonly IConfiguration _config;

    public RoleRepository(IConfiguration config)
    {
        _config = config;
    }

    private IDbConnection Connection =>
        new SqlConnection(_config.GetConnectionString("DefaultConnection"));

    public async Task<string> Insert(RoleDto role)
    {
        using var db = Connection;

        return await db.QueryFirstAsync<string>(
            "IUD_RoleMaster",
            new
            {
                Action = "INSERT",
                role.RoleName,
                role.CompanyId,
                role.Description
            },
            commandType: CommandType.StoredProcedure
        );
    }

    public async Task<string> Update(RoleDto role)
    {
        using var db = Connection;

        return await db.QueryFirstAsync<string>(
            "IUD_RoleMaster",
            new
            {
                Action = "UPDATE",
                role.Id,
                role.RoleName,
                role.CompanyId,
                role.Description,
                role.IsActive
            },
            commandType: CommandType.StoredProcedure
        );
    }

    public async Task<string> Delete(int id)
    {
        using var db = Connection;

        return await db.QueryFirstAsync<string>(
            "IUD_RoleMaster",
            new
            {
                Action = "DELETE",
                Id = id
            },
            commandType: CommandType.StoredProcedure
        );
    }

    public async Task<IEnumerable<RoleDto>> List(int? companyId)
    {
        using var db = Connection;

        return await db.QueryAsync<RoleDto>(
            "IUD_RoleMaster",
            new
            {
                Action = "LIST",
                CompanyId = companyId
            },
            commandType: CommandType.StoredProcedure
        );
    }
}
